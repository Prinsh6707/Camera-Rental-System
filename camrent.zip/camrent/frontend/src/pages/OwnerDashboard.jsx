import React, { useState, useEffect, useCallback } from 'react';
import Navbar from '../components/Navbar';
import { CameraCardOwner, StatusBadge } from '../components/CameraCard';
import CameraModal from '../components/CameraModal';
import ReturnModal from '../components/ReturnModal';
import api from '../utils/api';
import toast from 'react-hot-toast';
import { IconPlus, IconCamera, IconCheck, IconClock, IconCoin, IconBell, IconSearch, IconFilter, IconPhone, IconX, IconChevronDown } from '@tabler/icons-react';

const TABS = ['Cameras', 'Active Rentals', 'Requests', 'History'];

export default function OwnerDashboard() {
  const [tab, setTab] = useState(0);
  const [cameras, setCameras] = useState([]);
  const [bookings, setBookings] = useState([]);
  const [stats, setStats] = useState({});
  const [loading, setLoading] = useState(true);
  const [camModal, setCamModal] = useState(false);
  const [editCam, setEditCam] = useState(null);
  const [returnModal, setReturnModal] = useState(false);
  const [returnBooking, setReturnBooking] = useState(null);
  const [counterModal, setCounterModal] = useState(false);
  const [counterBooking, setCounterBooking] = useState(null);
  const [counterPrice, setCounterPrice] = useState('');
  const [counterMsg, setCounterMsg] = useState('');
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('');

  const load = useCallback(async () => {
    try {
      const [cRes, bRes, sRes] = await Promise.all([
        api.get('/cameras/owner'),
        api.get('/bookings/owner'),
        api.get('/dashboard/owner/stats'),
      ]);
      setCameras(cRes.data);
      setBookings(bRes.data);
      setStats(sRes.data);
    } catch (err) {
      toast.error('Failed to load data');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { load(); }, [load]);

  const handleDelete = async (id) => {
    if (!window.confirm('Delete this camera?')) return;
    try {
      await api.delete(`/cameras/${id}`);
      toast.success('Camera deleted');
      load();
    } catch { toast.error('Failed to delete'); }
  };

  const handleBookingAction = async (id, action) => {
    try {
      await api.put(`/bookings/${id}/${action}`);
      toast.success(action === 'accept' ? '✅ Booking accepted' : '❌ Booking rejected');
      load();
    } catch { toast.error('Action failed'); }
  };

  const handleCounter = async () => {
    if (!counterPrice) { toast.error('Enter a counter price'); return; }
    try {
      await api.put(`/bookings/${counterBooking.id}/counter`, { counter_price: parseFloat(counterPrice), message: counterMsg });
      toast.success('Counter offer sent!');
      setCounterModal(false);
      load();
    } catch { toast.error('Failed to send counter'); }
  };

  const filteredCameras = cameras.filter(c => {
    const matchQ = !search || c.name.toLowerCase().includes(search.toLowerCase()) || c.brand.toLowerCase().includes(search.toLowerCase());
    const matchS = !statusFilter || c.status === statusFilter;
    return matchQ && matchS;
  });

  const pendingRequests = bookings.filter(b => b.status === 'Pending');
  const activeRentals = bookings.filter(b => b.status === 'Accepted');
  const history = bookings.filter(b => ['Returned', 'Rejected'].includes(b.status));

  if (loading) return <div className="loading-page"><div className="spinner" style={{ width: 32, height: 32 }} /></div>;

  return (
    <Navbar>
      <div className="page">
        {/* Header */}
        <div className="page-header">
          <div>
            <h1 className="page-title">Owner Dashboard</h1>
            <p className="page-subtitle">Manage your cameras and bookings</p>
          </div>
          <button className="btn btn-primary" onClick={() => { setEditCam(null); setCamModal(true); }}>
            <IconPlus size={16} /> Add Camera
          </button>
        </div>

        {/* Stats */}
        <div className="grid-4 mb-4">
          <div className="stat-card">
            <div className="stat-icon" style={{ background: 'var(--blue-light)' }}><IconCamera size={18} style={{ color: 'var(--blue)' }} /></div>
            <div className="stat-value">{stats.total_cameras || 0}</div>
            <div className="stat-label">Total Cameras</div>
          </div>
          <div className="stat-card">
            <div className="stat-icon" style={{ background: 'var(--green-light)' }}><IconCheck size={18} style={{ color: 'var(--green)' }} /></div>
            <div className="stat-value">{stats.available || 0}</div>
            <div className="stat-label">Available</div>
          </div>
          <div className="stat-card">
            <div className="stat-icon" style={{ background: 'var(--amber-light)' }}><IconClock size={18} style={{ color: 'var(--amber)' }} /></div>
            <div className="stat-value">{stats.rented || 0}</div>
            <div className="stat-label">Rented Out</div>
          </div>
          <div className="stat-card">
            <div className="stat-icon" style={{ background: 'var(--teal-light)' }}><IconCoin size={18} style={{ color: 'var(--teal)' }} /></div>
            <div className="stat-value">₹{(stats.total_earnings || 0).toLocaleString('en-IN')}</div>
            <div className="stat-label">Total Earnings</div>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex-center gap-2 mb-3">
          <div className="tabs">
            {TABS.map((t, i) => (
              <button key={t} className={`tab ${tab === i ? 'active' : ''}`} onClick={() => setTab(i)}>
                {t} {i === 2 && pendingRequests.length > 0 && <span style={{ background: 'var(--blue)', color: '#fff', borderRadius: '50%', fontSize: 10, padding: '1px 5px', marginLeft: 4 }}>{pendingRequests.length}</span>}
              </button>
            ))}
          </div>
        </div>

        {/* ─── Cameras Tab ─── */}
        {tab === 0 && (
          <>
            <div style={{ display: 'flex', gap: 10, marginBottom: 16, flexWrap: 'wrap' }}>
              <div style={{ position: 'relative', flex: '1 1 220px' }}>
                <IconSearch size={14} style={{ position: 'absolute', left: 10, top: '50%', transform: 'translateY(-50%)', color: 'var(--gray-400)' }} />
                <input className="form-control" style={{ paddingLeft: 32 }} placeholder="Search cameras..." value={search} onChange={e => setSearch(e.target.value)} />
              </div>
              <select className="form-control" style={{ flex: '0 0 160px' }} value={statusFilter} onChange={e => setStatusFilter(e.target.value)}>
                <option value="">All Status</option>
                <option>Available</option>
                <option>Rented</option>
              </select>
            </div>
            {filteredCameras.length === 0
              ? <div className="empty-state"><div className="empty-state-icon">📷</div><p>No cameras yet. Add your first camera!</p></div>
              : <div className="grid-cameras">{filteredCameras.map(c => (
                <CameraCardOwner key={c.id} camera={c} onEdit={cam => { setEditCam(cam); setCamModal(true); }} onDelete={handleDelete} />
              ))}</div>
            }
          </>
        )}

        {/* ─── Active Rentals Tab ─── */}
        {tab === 1 && (
          <div className="table-container">
            {activeRentals.length === 0
              ? <div className="empty-state"><div className="empty-state-icon">📋</div><p>No active rentals</p></div>
              : <table>
                <thead><tr>
                  <th>Renter</th><th>Camera</th><th>Issue Date</th><th>Return Date</th>
                  <th>Rate/Day</th><th>Total</th><th>Contact</th><th>Action</th>
                </tr></thead>
                <tbody>
                  {activeRentals.map(b => (
                    <tr key={b.id}>
                      <td>
                        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                          <div className="avatar">{b.renter_name.charAt(0)}</div>
                          <div>
                            <div style={{ fontWeight: 500 }}>{b.renter_name}</div>
                            {b.renter_id_proof && <div style={{ fontSize: 11, color: 'var(--gray-400)' }}>{b.renter_id_proof}</div>}
                          </div>
                        </div>
                      </td>
                      <td style={{ fontWeight: 500 }}>{b.camera_name}</td>
                      <td>{b.issue_date}</td>
                      <td>{b.return_date}</td>
                      <td>₹{b.offered_price?.toLocaleString('en-IN')}</td>
                      <td style={{ fontWeight: 600, color: 'var(--green)' }}>₹{b.total_amount?.toLocaleString('en-IN')}</td>
                      <td>
                        <a href={`tel:${b.renter_phone}`} style={{ color: 'var(--blue)', display: 'flex', alignItems: 'center', gap: 4, fontSize: 12 }}>
                          <IconPhone size={12} />{b.renter_phone}
                        </a>
                      </td>
                      <td>
                        <button className="btn btn-success btn-sm" onClick={() => { setReturnBooking(b); setReturnModal(true); }}>
                          <IconCheck size={13} /> Return
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            }
          </div>
        )}

        {/* ─── Requests Tab ─── */}
        {tab === 2 && (
          <div className="table-container">
            {bookings.filter(b => ['Pending','Counter'].includes(b.status)).length === 0
              ? <div className="empty-state"><div className="empty-state-icon">📩</div><p>No pending requests</p></div>
              : <table>
                <thead><tr>
                  <th>Renter</th><th>Camera</th><th>Dates</th><th>Offered Price</th>
                  <th>Listed Price</th><th>Reason</th><th>Status</th><th>Actions</th>
                </tr></thead>
                <tbody>
                  {bookings.filter(b => ['Pending','Counter'].includes(b.status)).map(b => {
                    const discount = b.listed_price > 0 ? Math.round((b.listed_price - b.offered_price) / b.listed_price * 100) : 0;
                    return (
                      <tr key={b.id}>
                        <td>
                          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                            <div className="avatar">{b.renter_name.charAt(0)}</div>
                            <div>
                              <div style={{ fontWeight: 500 }}>{b.renter_name}</div>
                              <a href={`tel:${b.renter_phone}`} style={{ fontSize: 11, color: 'var(--blue)' }}>{b.renter_phone}</a>
                            </div>
                          </div>
                        </td>
                        <td style={{ fontWeight: 500 }}>{b.camera_name}</td>
                        <td style={{ fontSize: 12 }}>{b.issue_date}<br />{b.return_date}</td>
                        <td>
                          <span style={{ fontWeight: 600, color: b.offered_price < b.listed_price ? 'var(--red)' : 'var(--green)' }}>
                            ₹{b.offered_price?.toLocaleString('en-IN')}
                          </span>
                          {discount > 0 && <div style={{ fontSize: 10, color: 'var(--gray-400)' }}>-{discount}% off</div>}
                        </td>
                        <td>₹{b.listed_price?.toLocaleString('en-IN')}</td>
                        <td style={{ fontSize: 12, color: 'var(--gray-500)', maxWidth: 120 }}>{b.bargain_reason || '—'}</td>
                        <td><StatusBadge status={b.status} /></td>
                        <td>
                          <div style={{ display: 'flex', gap: 5 }}>
                            <button className="btn btn-success btn-sm" onClick={() => handleBookingAction(b.id, 'accept')}>✓</button>
                            <button className="btn btn-secondary btn-sm" onClick={() => { setCounterBooking(b); setCounterPrice(b.listed_price); setCounterMsg(''); setCounterModal(true); }}>Counter</button>
                            <button className="btn btn-danger btn-sm" onClick={() => handleBookingAction(b.id, 'reject')}>✕</button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            }
          </div>
        )}

        {/* ─── History Tab ─── */}
        {tab === 3 && (
          <div className="table-container">
            {history.length === 0
              ? <div className="empty-state"><div className="empty-state-icon">📅</div><p>No history yet</p></div>
              : <table>
                <thead><tr><th>Renter</th><th>Camera</th><th>Period</th><th>Amount</th><th>Status</th></tr></thead>
                <tbody>
                  {history.map(b => (
                    <tr key={b.id}>
                      <td style={{ fontWeight: 500 }}>{b.renter_name}</td>
                      <td>{b.camera_name}</td>
                      <td style={{ fontSize: 12 }}>{b.issue_date} → {b.return_date}</td>
                      <td style={{ fontWeight: 600, color: 'var(--green)' }}>₹{(b.final_payment || b.total_amount || 0).toLocaleString('en-IN')}</td>
                      <td><StatusBadge status={b.status} /></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            }
          </div>
        )}
      </div>

      {/* Modals */}
      {camModal && <CameraModal camera={editCam} onClose={() => { setCamModal(false); setEditCam(null); }} onSaved={load} />}
      {returnModal && <ReturnModal booking={returnBooking} onClose={() => setReturnModal(false)} onReturned={load} />}

      {/* Counter Offer Modal */}
      {counterModal && counterBooking && (
        <div className="modal-overlay" onClick={e => e.target === e.currentTarget && setCounterModal(false)}>
          <div className="modal">
            <div className="modal-header">
              <h2 className="modal-title">Counter Offer</h2>
              <button className="btn-icon" onClick={() => setCounterModal(false)}><IconX size={16} /></button>
            </div>
            <p style={{ fontSize: 13, color: 'var(--gray-600)', marginBottom: 16 }}>
              <strong>{counterBooking.renter_name}</strong> offered <strong style={{ color: 'var(--red)' }}>₹{counterBooking.offered_price}</strong>/day on <strong>{counterBooking.camera_name}</strong> (listed ₹{counterBooking.listed_price})
            </p>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
              <div className="form-group">
                <label className="form-label">Your Counter Price (₹/day)</label>
                <input className="form-control" type="number" value={counterPrice} onChange={e => setCounterPrice(e.target.value)} />
              </div>
              <div className="form-group">
                <label className="form-label">Message (optional)</label>
                <textarea className="form-control" rows={2} placeholder="e.g. Best I can offer for 3 days..." value={counterMsg} onChange={e => setCounterMsg(e.target.value)} />
              </div>
              <div style={{ display: 'flex', gap: 10, justifyContent: 'flex-end' }}>
                <button className="btn btn-secondary" onClick={() => setCounterModal(false)}>Cancel</button>
                <button className="btn btn-primary" onClick={handleCounter}>Send Counter Offer</button>
              </div>
            </div>
          </div>
        </div>
      )}
    </Navbar>
  );
}
