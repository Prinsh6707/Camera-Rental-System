# 📷 CamRent — Camera Rental Management Platform

Full-stack camera rental management app with dual login system, bargaining, and real-time booking management.

## Tech Stack

| Layer      | Technology                        |
|------------|-----------------------------------|
| Frontend   | React (CRA) + Tailwind-style CSS  |
| Backend    | FastAPI (Python)                  |
| Database   | MongoDB (via Motor async driver)  |
| Auth       | JWT (python-jose + bcrypt)        |

---

## Quick Start (Manual)

### Prerequisites
- Python 3.10+
- Node.js 18+
- MongoDB running on localhost:27017

### 1. Backend Setup

```bash
cd backend
pip install -r requirements.txt
uvicorn main:app --reload --port 8000
```

Backend runs at: http://localhost:8000  
API docs (Swagger): http://localhost:8000/docs

### 2. Frontend Setup

```bash
cd frontend
npm install
npm start
```

Frontend runs at: http://localhost:3000

---

## Quick Start (Docker)

```bash
docker-compose up --build
```

That's it! Starts MongoDB, backend, and frontend together.

---

## Features

### Camera Owner Dashboard
- Register/login as an owner
- Add cameras with photo upload, specs, pricing
- Edit and delete cameras
- View live stats: total cameras, available, rented, earnings
- **Active Rentals tab**: see renter name, phone, dates, total amount — mark as returned
- **Booking Requests tab**: Accept / Reject / Counter-offer on each booking
- **History tab**: full record of past rentals with earnings

### Renter Dashboard
- Register/login as a renter
- Browse cameras with filters: type, max price, sort by price/rating
- View camera specs, condition, accessories, owner info
- **Book Now flow**: name, phone, ID proof, dates
- **Bargaining system**: offer a custom price per day — live feedback shows if offer is reasonable
- **My Bookings tab**: track booking status (Pending / Accepted / Counter / Rejected / Returned)

### Bargaining System
- Renter enters their offered price
- Live feedback: 0-15% off = green (likely accepted), 15-30% = orange (counter likely), 30%+ = red (too low)
- Owner can accept, reject, or send a counter price with a message
- Renter sees counter price on their bookings tab

---

## API Endpoints

### Auth
- `POST /auth/register` — register user
- `POST /auth/login` — login (returns JWT)
- `GET /auth/me` — get current user

### Cameras
- `GET /cameras` — list all (with filters)
- `POST /cameras` — add camera (owner)
- `GET /cameras/owner` — owner's cameras
- `PUT /cameras/{id}` — update camera
- `DELETE /cameras/{id}` — delete camera

### Bookings
- `POST /bookings` — create booking request (renter)
- `GET /bookings/owner` — owner's bookings
- `GET /bookings/renter` — renter's bookings
- `PUT /bookings/{id}/accept` — accept booking
- `PUT /bookings/{id}/reject` — reject booking
- `PUT /bookings/{id}/counter` — counter offer
- `PUT /bookings/{id}/return` — process return

### Dashboard
- `GET /dashboard/owner/stats` — owner stats

---

## Environment Variables

### Backend (.env)
```
SECRET_KEY=your-super-secret-jwt-key
MONGO_URL=mongodb://localhost:27017
```

### Frontend (.env)
```
REACT_APP_API_URL=http://localhost:8000
```

---

## Project Structure

```
camrent/
├── backend/
│   ├── main.py              # FastAPI app (all routes)
│   ├── requirements.txt
│   ├── Dockerfile
│   └── .env.example
├── frontend/
│   ├── public/
│   │   └── index.html
│   ├── src/
│   │   ├── App.jsx           # Router + Auth wrapper
│   │   ├── index.css         # Full design system
│   │   ├── context/
│   │   │   └── AuthContext.jsx
│   │   ├── utils/
│   │   │   └── api.js        # Axios + JWT interceptors
│   │   ├── components/
│   │   │   ├── Navbar.jsx
│   │   │   ├── CameraCard.jsx
│   │   │   ├── CameraModal.jsx
│   │   │   └── ReturnModal.jsx
│   │   └── pages/
│   │       ├── Login.jsx
│   │       ├── Register.jsx
│   │       ├── OwnerDashboard.jsx
│   │       └── RenterDashboard.jsx
│   ├── package.json
│   └── Dockerfile
└── docker-compose.yml
```
