import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import { AuthProvider, useAuth } from './context/AuthContext';
import Login from './pages/Login';
import Register from './pages/Register';
import OwnerDashboard from './pages/OwnerDashboard';
import RenterDashboard from './pages/RenterDashboard';
import './index.css';

function PrivateRoute({ children, role }) {
  const { user, loading } = useAuth();
  if (loading) return <div className="loading-page"><div className="spinner" style={{width:32,height:32}} /></div>;
  if (!user) return <Navigate to="/login" replace />;
  if (role && user.role !== role) return <Navigate to={user.role === 'owner' ? '/owner' : '/browse'} replace />;
  return children;
}

function AppRoutes() {
  const { user } = useAuth();
  return (
    <Routes>
      <Route path="/login" element={user ? <Navigate to={user.role === 'owner' ? '/owner' : '/browse'} replace /> : <Login />} />
      <Route path="/register" element={user ? <Navigate to={user.role === 'owner' ? '/owner' : '/browse'} replace /> : <Register />} />
      <Route path="/owner/*" element={<PrivateRoute role="owner"><OwnerDashboard /></PrivateRoute>} />
      <Route path="/browse/*" element={<PrivateRoute role="renter"><RenterDashboard /></PrivateRoute>} />
      <Route path="/" element={<Navigate to="/login" replace />} />
      <Route path="*" element={<Navigate to="/login" replace />} />
    </Routes>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <AppRoutes />
        <Toaster
          position="top-right"
          toastOptions={{
            duration: 3000,
            style: { fontFamily: 'Inter, sans-serif', fontSize: 13, borderRadius: 10 },
          }}
        />
      </BrowserRouter>
    </AuthProvider>
  );
}
