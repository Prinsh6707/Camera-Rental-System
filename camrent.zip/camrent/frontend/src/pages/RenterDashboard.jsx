import React, { useState, useEffect, useCallback } from 'react';
import Navbar from '../components/Navbar';
import { CameraCardRenter, StatusBadge } from '../components/CameraCard';
import api from '../utils/api';
import toast from 'react-hot-toast';
import { differenceInDays, parseISO } from 'date-fns';
import { IconSearch, IconX, IconCoin, IconCalendar } from '@tabler/icons-react';

const TABS = ['Browse Cameras', 'My Bookings'];
const TYPES = ['', 'DSLR', 'Mirrorless', 'Cinema', 'Action'];

function getBargainClass(pct) {
  if (pct <= 0) return 'bargain-great';
  if (pct <= 15) return 'bargain-ok';
  if (pct <= 30) return 'bargain-warn';
  return 'bargain-bad';
}
function getBargainMsg(pct) {
  if (pct <= 0) return '🎉 Your offer matches or exceeds the listed price — guaranteed to be accepted!';
  if (pct <= 15) return `💬 ${pct}% below listed — reasonable offer with a good chance of acceptance.`;
  if (pct <= 30) return `🤝 ${pct}% below listed — owner may send a counter offer. Add a reason to improve chances.`;
  return `⚠️ ${pct}% below listed — this is quite low. Try a higher offer or add a compelling reason.`;
}

export default function RenterDashboard() {
  const [tab, setTab] = useState(0);
  const [cameras, setCameras] = useState([]);
  const [bookings, setBookings] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [typeFilter, setTypeFilter] = useState('');
  const [sortBy, setSortBy] = useState('price_asc');
  const [maxPrice, setMaxPrice] = useState('');

  const [bookModal, setBookModal] = useState(false);
  const [bookCam, setBookCam] = useState(null);
  const [bookForm, setBookForm] = useState({ renter_name: '', renter_phone: '', renter_id_proof: '', issue_date: '', return_date: '', offered_price: '', bargain_reason: '', notes: '' });
  const [bookLoading, setBookLoading] = useState(false);

  const today = new Date().toISOString().split('T')[0];

  const loadCameras = useCallback(async () => {
    try {
      const params = new URLSearchParams();
      if (typeFilter) params.set('type', typeFilter);
      if (maxPrice) params.set('max_price', maxPrice);
      if (search) params.set('search', search);
      params.set('sort', sortBy);
      const res = await api.get(`/cameras?${params}`);
      setCameras(res.data);
    } catch { toast.error('Failed to load cameras'); }
  }, [typeFilter, maxPrice, search, sortBy]);

  const loadBookings = useCallback(async () => {
    try {
      const res = await api.get('/bookings/renter');
      setBookings(res.data);
    } catch {}
  }, []);

  useEffect(() => {
    Promise.all([loadCameras(), loadBookings()]).finally(() => setLoading(false));
  }, [loadCameras, loadBookings]);

  const openBook = (cam) => {
    setBookCam(cam);
    setBookForm({ renter_name: '', renter_phone: '', renter_id_proof: '', issue_date: today, return_date: '', offered_price: cam.price_per_day, bargain_reason: '', notes: '' });
    setBookModal(true);
  };

  const setField = (k) => (e) => setBookForm(f => ({ ...f, [k]: e.target.value }));

  const days = bookForm.issue_date && bookForm.return_date
    ? Math.max(1, differenceInDays(parseISO(bookForm.return_date), parseISO(bookForm.issue_date)))
    : 0;
  const totalAmount = days * (parseFloat(bookForm.offered_price) || bookCam?.price_per_day || 0);
  const discountPct = bookCam ? Math.round((bookCam.price_per_day - (parseFloat(bookForm.offered_price) || bookCam.price_per_day)) / bookCam.price_per_day * 100) : 0;

  const submitBooking = async () => {
    const { renter_name, renter_phone, issue_date, return_date, offered_price } = bookForm;
    if (!renter_name || !renter_phone || !issue_date || !return_date || !offered_price) {
      toast.error('Please fill all required fields'); return;
    }
    setBookLoading(true);
    try {
      await api.post('/bookings', {
        camera_id: bookCam.id,
        renter_name,
        renter_phone,
        renter_id_proof: bookForm.renter_id_proof,
        issue_date,
        return_date,
        offered_price: parseFloat(offered_price),
        listed_price: bookCam.price_per_day,
        bargain_reason: bookForm.bargain_reason,
        notes: bookForm.notes,
      });
      toast.success('Booking request sent! Owner will confirm soon.');
      setBookModal(false);
      loadBookings();
    } catch (err) {
      toast.error(err.response?.data?.detail || 'Failed to send booking');
    } finally {
      setBookLoading(false);
    }
  };

  if (loading) return <div className="loading-page"><div className="spinner" style={{ width: 32, height: 32 }} /></div>;

  return (
    <Navbar>
      <div className="page">
        <div className="page-header">
          <div>
            <h1 className="page-title">Camera Marketplace</h1>
            <p className="page-subtitle">Find and book the perfect camera for your shoot</p>
          </div>
        </div>

        <div className="tabs mb-3">
          {TABS.map((t, i) => (
            <button key={t} className={`tab ${tab === i ? 'active' : ''}`} onClick={() => setTab(i)}>
              {t} {i === 1 && bookings.length > 0 && <span style={{ background: 'var(--blue)', color: '#fff', borderRadius: '50%', fontSize: 10, padding: '1px 5px', marginLeft: 4 }}>{bookings.length}</span>}
            </button>
          ))}
        </div>

        {/* ─── Browse Tab ─── */}
        {tab === 0 && (
          <>
            <div style={{ display: 'flex', gap: 10, marginBottom: 18, flexWrap: 'wrap' }}>
              <div style={{ position: 'relative', flex: '1 1 220px' }}>
                <IconSearch size={14} style={{ position: 'absolute', left: 10, top: '50%', transform: 'translateY(-50%)', color: 'var(--gray-400)' }} />
                <input className="form-control" style={{ paddingLeft: 32 }} placeholder="Search cameras, brands..." value={search} onChange={e => setSearch(e.target.value)} />
              </div>
              <select className="form-control" style={{ flex: '0 0 150px' }} value={typeFilter} onChange={e => setTypeFilter(e.target.value)}>
                <option value="">All Types</option>
                {['DSLR','Mirrorless','Cinema','Action'].map(t => <option key={t}>{t}</option>)}
              </select>
              <select className="form-control" style={{ flex: '0 0 170px' }} value={sortBy} onChange={e => setSortBy(e.target.value)}>
                <option value="price_asc">Price: Low to High</option>
                <option value="price_desc">Price: High to Low</option>
                <option value="rating">Top Rated</option>
              </select>
              <input className="form-control" type="number" style={{ flex: '0 0 130px' }} placeholder="Max ₹/day" value={maxPrice} onChange={e => setMaxPrice(e.target.value)} />
            </div>
            {cameras.length === 0
              ? <div className="empty-state"><div className="empty-state-icon">🔍</div><p>No cameras match your filters</p></div>
              : <div className="grid-cameras">{cameras.map(c => <CameraCardRenter key={c.id} camera={c} onBook={openBook} />)}</div>
            }
          </>
        )}

        {/* ─── My Bookings Tab ─── */}
        {tab === 1 && (
          <div className="table-container">
            {bookings.length === 0
              ? <div className="empty-state"><div className="empty-state-icon"><IconCalendar size={48} /></div><p>No bookings yet. Browse cameras to get started!</p></div>
              : <table>
                <thead><tr>
                  <th>Camera</th><th>Owner</th><th>Dates</th><th>Offered</th><th>Total</th><th>Status</th><th>Notes</th>
                </tr></thead>
                <tbody>
                  {bookings.map(b => (
                    <tr key={b.id}>
                      <td style={{ fontWeight: 500 }}>{b.camera_name}<div style={{ fontSize: 11, color: 'var(--gray-400)' }}>{b.camera_brand}</div></td>
                      <td style={{ fontSize: 13 }}>{b.owner_name}</td>
                      <td style={{ fontSize: 12 }}>{b.issue_date}<br />{b.return_date}</td>
                      <td>
                        <div>₹{b.offered_price?.toLocaleString('en-IN')}/day</div>
                        {b.listed_price !== b.offered_price && <div style={{ fontSize: 10, color: 'var(--gray-400)' }}>listed ₹{b.listed_price}</div>}
                      </td>
                      <td style={{ fontWeight: 600 }}>₹{b.total_amount?.toLocaleString('en-IN')}</td>
                      <td>
                        <StatusBadge status={b.status} />
                        {b.status === 'Counter' && b.counter_price && (
                          <div style={{ fontSize: 11, marginTop: 4, color: '#6A1B9A' }}>Counter: ₹{b.counter_price}/day</div>
                        )}
                      </td>
                      <td style={{ fontSize: 12, color: 'var(--gray-500)', maxWidth: 140 }}>{b.notes || b.bargain_reason || '—'}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            }
          </div>
        )}
      </div>

      {/* Booking Modal */}
      {bookModal && bookCam && (
        <div className="modal-overlay" onClick={e => e.target === e.currentTarget && setBookModal(false)}>
          <div className="modal modal-wide">
            <div className="modal-header">
              <h2 className="modal-title">Book Camera</h2>
              <button className="btn-icon" onClick={() => setBookModal(false)}><IconX size={16} /></button>
            </div>

            {/* Camera info strip */}
            <div style={{ background: 'var(--sky)', borderRadius: 'var(--radius-md)', padding: '10px 14px', marginBottom: 18, display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 8 }}>
              <div>
                <div style={{ fontWeight: 600, fontSize: 14 }}>{bookCam.name}</div>
                <div style={{ fontSize: 12, color: 'var(--gray-600)' }}>{bookCam.brand} · {bookCam.type} · {bookCam.sensor}</div>
              </div>
              <div style={{ textAlign: 'right' }}>
                <div style={{ fontSize: 18, fontWeight: 700, color: 'var(--blue)' }}>₹{bookCam.price_per_day.toLocaleString('en-IN')}/day</div>
                <div style={{ fontSize: 11, color: 'var(--gray-500)' }}>by {bookCam.owner_name}</div>
              </div>
            </div>

            <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
              <div className="grid-2">
                <div className="form-group">
                  <label className="form-label">Your Name *</label>
                  <input className="form-control" placeholder="Full name" value={bookForm.renter_name} onChange={setField('renter_name')} />
                </div>
                <div className="form-group">
                  <label className="form-label">Contact Number *</label>
                  <input className="form-control" placeholder="+91 XXXXX XXXXX" value={bookForm.renter_phone} onChange={setField('renter_phone')} />
                </div>
              </div>
              <div className="grid-2">
                <div className="form-group">
                  <label className="form-label">Issue Date *</label>
                  <input type="date" className="form-control" min={today} value={bookForm.issue_date} onChange={setField('issue_date')} />
                </div>
                <div className="form-group">
                  <label className="form-label">Return Date *</label>
                  <input type="date" className="form-control" min={bookForm.issue_date || today} value={bookForm.return_date} onChange={setField('return_date')} />
                </div>
              </div>
              <div className="form-group">
                <label className="form-label">ID Proof (Aadhar / Driving License)</label>
                <input className="form-control" placeholder="ID number" value={bookForm.renter_id_proof} onChange={setField('renter_id_proof')} />
              </div>

              {/* Price summary */}
              {days > 0 && (
                <div style={{ background: 'var(--green-light)', borderRadius: 'var(--radius-sm)', padding: '10px 14px', fontSize: 13 }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                    <span style={{ color: 'var(--gray-600)' }}>₹{bookForm.offered_price} × {days} days</span>
                    <span style={{ fontWeight: 700, color: '#2E7D32' }}>Total: ₹{totalAmount.toLocaleString('en-IN')}</span>
                  </div>
                </div>
              )}

              {/* Bargaining section */}
              <div className="bargain-box">
                <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8 }}>
                  <IconCoin size={16} style={{ color: 'var(--blue)' }} />
                  <span style={{ fontWeight: 600, fontSize: 13 }}>Make an Offer (Bargaining)</span>
                  <span style={{ background: 'var(--blue-light)', color: 'var(--blue)', borderRadius: 6, fontSize: 10, padding: '2px 7px', fontWeight: 600 }}>OPTIONAL</span>
                </div>
                <p style={{ fontSize: 12, color: 'var(--gray-500)', marginBottom: 10 }}>Propose a different price — the owner can accept, reject, or counter.</p>
                <div className="grid-2">
                  <div className="form-group">
                    <label className="form-label">Your Offer (₹/day) *</label>
                    <input className="form-control" type="number" min="1" placeholder={bookCam.price_per_day} value={bookForm.offered_price} onChange={setField('offered_price')} />
                  </div>
                  <div className="form-group">
                    <label className="form-label">Reason (helps get accepted)</label>
                    <input className="form-control" placeholder="Student / Long rental / etc." value={bookForm.bargain_reason} onChange={setField('bargain_reason')} />
                  </div>
                </div>
                {bookForm.offered_price && parseFloat(bookForm.offered_price) > 0 && (
                  <div className={`bargain-feedback ${getBargainClass(discountPct)}`}>
                    {getBargainMsg(discountPct)}
                  </div>
                )}
              </div>

              <div className="form-group">
                <label className="form-label">Additional Notes</label>
                <textarea className="form-control" rows={2} placeholder="Any special requirements, purpose of rental..." value={bookForm.notes} onChange={setField('notes')} />
              </div>

              <div style={{ display: 'flex', gap: 10, justifyContent: 'flex-end' }}>
                <button className="btn btn-secondary" onClick={() => setBookModal(false)}>Cancel</button>
                <button className="btn btn-primary" onClick={submitBooking} disabled={bookLoading}>
                  {bookLoading ? 'Sending...' : '📅 Send Booking Request'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </Navbar>
  );
}
