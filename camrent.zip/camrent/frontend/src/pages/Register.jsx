import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import toast from 'react-hot-toast';
import { IconCamera, IconBuildingStore, IconUser, IconMail, IconLock, IconPhone } from '@tabler/icons-react';

export default function Register() {
  const { register } = useAuth();
  const navigate = useNavigate();
  const [role, setRole] = useState('');
  const [form, setForm] = useState({ name: '', email: '', password: '', phone: '', studio_name: '' });
  const [loading, setLoading] = useState(false);

  const set = (k) => (e) => setForm(f => ({ ...f, [k]: e.target.value }));

  const handleRegister = async (e) => {
    e.preventDefault();
    if (!role) { toast.error('Please select a role'); return; }
    setLoading(true);
    try {
      const user = await register({ ...form, role });
      toast.success('Account created! Welcome 🎉');
      navigate(user.role === 'owner' ? '/owner' : '/browse');
    } catch (err) {
      toast.error(err.response?.data?.detail || 'Registration failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="auth-page">
      <div className="auth-card" style={{ maxWidth: 480 }}>
        <div style={{ textAlign: 'center', marginBottom: '1.5rem' }}>
          <div style={{ width: 50, height: 50, background: 'var(--blue)', borderRadius: 14, display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 10px' }}>
            <IconCamera size={24} color="white" />
          </div>
          <h1 style={{ fontSize: 22, fontWeight: 700 }}>Create Account</h1>
          <p style={{ fontSize: 13, color: 'var(--gray-500)', marginTop: 4 }}>Join CamRent today</p>
        </div>

        <p style={{ fontSize: 12, fontWeight: 600, color: 'var(--gray-500)', textTransform: 'uppercase', letterSpacing: '.06em', marginBottom: 10 }}>I am a</p>
        <div className="grid-2" style={{ marginBottom: '1.25rem' }}>
          {['owner', 'renter'].map(r => (
            <button key={r} type="button" className={`auth-role-btn ${role === r ? 'selected' : ''}`} onClick={() => setRole(r)}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                <div style={{ width: 34, height: 34, borderRadius: 9, background: role === r ? 'var(--blue)' : 'var(--gray-100)', display: 'flex', alignItems: 'center', justifyContent: 'center', transition: 'all .15s', flexShrink: 0 }}>
                  {r === 'owner' ? <IconBuildingStore size={18} color={role === r ? 'white' : 'var(--gray-500)'} /> : <IconUser size={18} color={role === r ? 'white' : 'var(--gray-500)'} />}
                </div>
                <div>
                  <div style={{ fontWeight: 600, fontSize: 13 }}>{r === 'owner' ? 'Camera Owner' : 'Renter'}</div>
                  <div style={{ fontSize: 11, color: 'var(--gray-500)' }}>{r === 'owner' ? 'List & earn' : 'Rent & shoot'}</div>
                </div>
              </div>
            </button>
          ))}
        </div>

        <div className="divider" />

        <form onSubmit={handleRegister} style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          <div className="grid-2">
            <div className="form-group">
              <label className="form-label">Full Name</label>
              <input className="form-control" placeholder="Your name" value={form.name} onChange={set('name')} required />
            </div>
            <div className="form-group">
              <label className="form-label">Phone</label>
              <div className="input-group">
                <IconPhone size={14} className="input-icon" />
                <input className="form-control" placeholder="+91 XXXXX" value={form.phone} onChange={set('phone')} />
              </div>
            </div>
          </div>
          {role === 'owner' && (
            <div className="form-group">
              <label className="form-label">Studio / Business Name</label>
              <input className="form-control" placeholder="e.g. Lens Masters Studio" value={form.studio_name} onChange={set('studio_name')} />
            </div>
          )}
          <div className="form-group">
            <label className="form-label">Email</label>
            <div className="input-group">
              <IconMail size={14} className="input-icon" />
              <input className="form-control" type="email" placeholder="you@example.com" value={form.email} onChange={set('email')} required />
            </div>
          </div>
          <div className="form-group">
            <label className="form-label">Password</label>
            <div className="input-group">
              <IconLock size={14} className="input-icon" />
              <input className="form-control" type="password" placeholder="Min. 6 characters" value={form.password} onChange={set('password')} minLength={6} required />
            </div>
          </div>
          <button type="submit" className="btn btn-primary btn-lg" style={{ width: '100%', justifyContent: 'center', marginTop: 4 }} disabled={loading}>
            {loading ? <><div className="spinner" style={{ width: 16, height: 16, borderWidth: 2, borderColor: 'rgba(255,255,255,.3)', borderTopColor: '#fff' }} /> Creating...</> : 'Create Account'}
          </button>
        </form>

        <p style={{ textAlign: 'center', marginTop: '1rem', fontSize: 13, color: 'var(--gray-500)' }}>
          Already have an account? <Link to="/login" style={{ color: 'var(--blue)', fontWeight: 500 }}>Log in</Link>
        </p>
      </div>
    </div>
  );
}
