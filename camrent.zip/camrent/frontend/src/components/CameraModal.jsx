import React, { useState, useEffect } from 'react';
import { IconX, IconUpload } from '@tabler/icons-react';
import api from '../utils/api';
import toast from 'react-hot-toast';

const TYPES = ['DSLR', 'Mirrorless', 'Cinema', 'Action'];
const CONDITIONS = ['Excellent', 'Good', 'Fair'];

const DEFAULTS = { name: '', brand: '', type: 'DSLR', price_per_day: '', megapixels: '', video: '', sensor: '', condition: 'Excellent', accessories: '', description: '', image_url: '' };

export default function CameraModal({ camera, onClose, onSaved }) {
  const [form, setForm] = useState(DEFAULTS);
  const [loading, setLoading] = useState(false);
  const [preview, setPreview] = useState('');

  useEffect(() => {
    if (camera) {
      setForm({ ...DEFAULTS, ...camera, price_per_day: camera.price_per_day || '' });
      setPreview(camera.image_url || '');
    }
  }, [camera]);

  const set = (k) => (e) => setForm(f => ({ ...f, [k]: e.target.value }));

  const handleImage = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => {
      setPreview(ev.target.result);
      setForm(f => ({ ...f, image_url: ev.target.result }));
    };
    reader.readAsDataURL(file);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.name || !form.price_per_day) { toast.error('Name and price are required'); return; }
    setLoading(true);
    try {
      if (camera?.id) {
        await api.put(`/cameras/${camera.id}`, { ...form, price_per_day: parseFloat(form.price_per_day) });
        toast.success('Camera updated!');
      } else {
        await api.post('/cameras', { ...form, price_per_day: parseFloat(form.price_per_day) });
        toast.success('Camera added!');
      }
      onSaved();
      onClose();
    } catch (err) {
      toast.error(err.response?.data?.detail || 'Failed to save camera');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="modal-overlay" onClick={e => e.target === e.currentTarget && onClose()}>
      <div className="modal modal-wide">
        <div className="modal-header">
          <h2 className="modal-title">{camera?.id ? 'Edit Camera' : 'Add New Camera'}</h2>
          <button className="btn-icon" onClick={onClose}><IconX size={16} /></button>
        </div>
        <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
          <div className="grid-2">
            <div className="form-group">
              <label className="form-label">Camera Name *</label>
              <input className="form-control" placeholder="e.g. Canon EOS R5" value={form.name} onChange={set('name')} required />
            </div>
            <div className="form-group">
              <label className="form-label">Brand *</label>
              <input className="form-control" placeholder="e.g. Canon, Sony" value={form.brand} onChange={set('brand')} required />
            </div>
          </div>
          <div className="grid-3">
            <div className="form-group">
              <label className="form-label">Type</label>
              <select className="form-control" value={form.type} onChange={set('type')}>
                {TYPES.map(t => <option key={t}>{t}</option>)}
              </select>
            </div>
            <div className="form-group">
              <label className="form-label">Price per Day (₹) *</label>
              <input className="form-control" type="number" min="1" placeholder="500" value={form.price_per_day} onChange={set('price_per_day')} required />
            </div>
            <div className="form-group">
              <label className="form-label">Condition</label>
              <select className="form-control" value={form.condition} onChange={set('condition')}>
                {CONDITIONS.map(c => <option key={c}>{c}</option>)}
              </select>
            </div>
          </div>
          <div className="grid-3">
            <div className="form-group">
              <label className="form-label">Resolution</label>
              <input className="form-control" placeholder="45 MP" value={form.megapixels} onChange={set('megapixels')} />
            </div>
            <div className="form-group">
              <label className="form-label">Video</label>
              <input className="form-control" placeholder="8K RAW" value={form.video} onChange={set('video')} />
            </div>
            <div className="form-group">
              <label className="form-label">Sensor</label>
              <input className="form-control" placeholder="Full Frame" value={form.sensor} onChange={set('sensor')} />
            </div>
          </div>
          <div className="form-group">
            <label className="form-label">Included Accessories</label>
            <input className="form-control" placeholder="50mm f/1.4 lens, 2 batteries, charger, bag" value={form.accessories} onChange={set('accessories')} />
          </div>
          <div className="form-group">
            <label className="form-label">Description</label>
            <textarea className="form-control" rows={2} placeholder="Camera features, ideal use cases..." value={form.description} onChange={set('description')} />
          </div>
          <div className="form-group">
            <label className="form-label">Camera Photo</label>
            <div className="upload-zone" onClick={() => document.getElementById('cam-img-input').click()}>
              {preview
                ? <img src={preview} alt="Preview" style={{ maxHeight: 100, borderRadius: 8, objectFit: 'cover' }} />
                : <><IconUpload size={22} style={{ color: 'var(--gray-400)', marginBottom: 6 }} /><p style={{ fontSize: 12, color: 'var(--gray-500)' }}>Click to upload camera photo</p><p style={{ fontSize: 11, color: 'var(--gray-400)' }}>PNG, JPG up to 5MB</p></>
              }
            </div>
            <input id="cam-img-input" type="file" accept="image/*" style={{ display: 'none' }} onChange={handleImage} />
            {preview && <button type="button" className="btn btn-ghost btn-sm" style={{ marginTop: 4 }} onClick={() => { setPreview(''); setForm(f => ({ ...f, image_url: '' })); }}>Remove photo</button>}
          </div>
          <div style={{ display: 'flex', gap: 10, justifyContent: 'flex-end', marginTop: 4 }}>
            <button type="button" className="btn btn-secondary" onClick={onClose}>Cancel</button>
            <button type="submit" className="btn btn-primary" disabled={loading}>
              {loading ? 'Saving...' : (camera?.id ? 'Save Changes' : 'Add Camera')}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
