import React, { useState } from 'react';
import { IconX } from '@tabler/icons-react';
import api from '../utils/api';
import toast from 'react-hot-toast';
import { differenceInDays, parseISO } from 'date-fns';

export default function ReturnModal({ booking, onClose, onReturned }) {
  const [payment, setPayment] = useState(booking?.total_amount || 0);
  const [condition, setCondition] = useState('Good');
  const [loading, setLoading] = useState(false);

  const days = booking ? Math.max(1, differenceInDays(parseISO(booking.return_date), parseISO(booking.issue_date))) : 0;

  const handleReturn = async () => {
    setLoading(true);
    try {
      await api.put(`/bookings/${booking.id}/return?final_payment=${payment}&return_condition=${condition}`);
      toast.success('Camera returned successfully!');
      onReturned();
      onClose();
    } catch (err) {
      toast.error('Failed to process return');
    } finally {
      setLoading(false);
    }
  };

  if (!booking) return null;

  return (
    <div className="modal-overlay" onClick={e => e.target === e.currentTarget && onClose()}>
      <div className="modal">
        <div className="modal-header">
          <h2 className="modal-title">Process Return</h2>
          <button className="btn-icon" onClick={onClose}><IconX size={16} /></button>
        </div>
        <div style={{ background: 'var(--sky)', borderRadius: 'var(--radius-md)', padding: '12px 14px', marginBottom: 16, fontSize: 13 }}>
          <strong>{booking.camera_name}</strong> rented to <strong>{booking.renter_name}</strong><br />
          <span style={{ color: 'var(--gray-600)' }}>{booking.issue_date} → {booking.return_date} ({days} days)</span><br />
          <span style={{ color: 'var(--blue)', fontWeight: 600 }}>Contact: {booking.renter_phone}</span>
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
          <div className="form-group">
            <label className="form-label">Camera Condition on Return</label>
            <select className="form-control" value={condition} onChange={e => setCondition(e.target.value)}>
              <option>Excellent — no issues</option>
              <option>Good — minor wear</option>
              <option>Fair — some issues</option>
              <option>Damaged — needs repair</option>
            </select>
          </div>
          <div className="form-group">
            <label className="form-label">Final Payment Received (₹)</label>
            <input className="form-control" type="number" value={payment} onChange={e => setPayment(e.target.value)} />
            <p style={{ fontSize: 11, color: 'var(--gray-400)', marginTop: 3 }}>Expected: ₹{booking.total_amount?.toLocaleString('en-IN')} ({days} days × ₹{booking.offered_price}/day)</p>
          </div>
          <div style={{ display: 'flex', gap: 10, justifyContent: 'flex-end' }}>
            <button className="btn btn-secondary" onClick={onClose}>Cancel</button>
            <button className="btn btn-success" onClick={handleReturn} disabled={loading}>
              {loading ? 'Processing...' : '✓ Confirm Return'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
