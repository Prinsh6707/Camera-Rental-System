from fastapi import FastAPI, Depends, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from motor.motor_asyncio import AsyncIOMotorClient
from pydantic import BaseModel, Field
from typing import Optional, List
from datetime import datetime, timedelta
from jose import JWTError, jwt
from passlib.context import CryptContext
from bson import ObjectId
import os

SECRET_KEY = os.getenv("SECRET_KEY", "camrent-super-secret-key-2024")
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 60 * 24

MONGO_URL = os.getenv("MONGO_URL", "mongodb://localhost:27017")
DB_NAME = "camrent"

app = FastAPI(title="CamRent API", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000", "http://127.0.0.1:3000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/auth/login")

client = AsyncIOMotorClient(MONGO_URL)
db = client[DB_NAME]


def pyobjectid(oid):
    return str(oid) if oid else None


class PyObjectId(ObjectId):
    @classmethod
    def __get_validators__(cls):
        yield cls.validate

    @classmethod
    def validate(cls, v):
        if not ObjectId.is_valid(v):
            raise ValueError("Invalid ObjectId")
        return ObjectId(v)


# ─── Models ───────────────────────────────────────────────────────────────────

class UserRegister(BaseModel):
    name: str
    email: str
    password: str
    role: str  # "owner" | "renter"
    phone: Optional[str] = None
    studio_name: Optional[str] = None

class UserLogin(BaseModel):
    email: str
    password: str
    role: str

class Token(BaseModel):
    access_token: str
    token_type: str
    user: dict

class CameraIn(BaseModel):
    name: str
    brand: str
    type: str
    price_per_day: float
    megapixels: Optional[str] = None
    video: Optional[str] = None
    sensor: Optional[str] = None
    condition: str = "Excellent"
    accessories: Optional[str] = None
    description: Optional[str] = None
    image_url: Optional[str] = None

class CameraOut(CameraIn):
    id: str
    owner_id: str
    owner_name: str
    status: str = "Available"
    rating: float = 0.0
    review_count: int = 0
    created_at: datetime

class BookingIn(BaseModel):
    camera_id: str
    renter_name: str
    renter_phone: str
    renter_id_proof: Optional[str] = None
    issue_date: str
    return_date: str
    offered_price: float
    listed_price: float
    bargain_reason: Optional[str] = None
    notes: Optional[str] = None

class BookingOut(BookingIn):
    id: str
    camera_name: str
    camera_brand: str
    owner_id: str
    owner_name: str
    renter_id: str
    status: str
    created_at: datetime
    total_amount: float

class BargainCounter(BaseModel):
    counter_price: float
    message: Optional[str] = None

class ReviewIn(BaseModel):
    camera_id: str
    rating: int
    comment: Optional[str] = None


# ─── Auth Helpers ──────────────────────────────────────────────────────────────

def hash_password(password: str) -> str:
    return pwd_context.hash(password)

def verify_password(plain: str, hashed: str) -> bool:
    return pwd_context.verify(plain, hashed)

def create_token(data: dict, expires_delta: timedelta = None) -> str:
    to_encode = data.copy()
    expire = datetime.utcnow() + (expires_delta or timedelta(minutes=15))
    to_encode.update({"exp": expire})
    return jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)

async def get_current_user(token: str = Depends(oauth2_scheme)):
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        user_id: str = payload.get("sub")
        if user_id is None:
            raise credentials_exception
    except JWTError:
        raise credentials_exception
    user = await db.users.find_one({"_id": ObjectId(user_id)})
    if user is None:
        raise credentials_exception
    return user

async def require_owner(user=Depends(get_current_user)):
    if user.get("role") != "owner":
        raise HTTPException(status_code=403, detail="Owner access required")
    return user

async def require_renter(user=Depends(get_current_user)):
    if user.get("role") != "renter":
        raise HTTPException(status_code=403, detail="Renter access required")
    return user


# ─── Auth Routes ──────────────────────────────────────────────────────────────

@app.post("/auth/register", response_model=Token)
async def register(data: UserRegister):
    existing = await db.users.find_one({"email": data.email, "role": data.role})
    if existing:
        raise HTTPException(status_code=400, detail="Email already registered for this role")
    
    user_doc = {
        "name": data.name,
        "email": data.email,
        "password": hash_password(data.password),
        "role": data.role,
        "phone": data.phone,
        "studio_name": data.studio_name,
        "created_at": datetime.utcnow(),
    }
    result = await db.users.insert_one(user_doc)
    user_id = str(result.inserted_id)
    
    token = create_token(
        {"sub": user_id, "role": data.role},
        timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    )
    return {
        "access_token": token,
        "token_type": "bearer",
        "user": {
            "id": user_id,
            "name": data.name,
            "email": data.email,
            "role": data.role,
            "studio_name": data.studio_name,
        }
    }

@app.post("/auth/login", response_model=Token)
async def login(data: UserLogin):
    user = await db.users.find_one({"email": data.email, "role": data.role})
    if not user or not verify_password(data.password, user["password"]):
        raise HTTPException(status_code=401, detail="Invalid credentials")
    
    token = create_token(
        {"sub": str(user["_id"]), "role": user["role"]},
        timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    )
    return {
        "access_token": token,
        "token_type": "bearer",
        "user": {
            "id": str(user["_id"]),
            "name": user["name"],
            "email": user["email"],
            "role": user["role"],
            "studio_name": user.get("studio_name"),
            "phone": user.get("phone"),
        }
    }

@app.get("/auth/me")
async def get_me(user=Depends(get_current_user)):
    return {
        "id": str(user["_id"]),
        "name": user["name"],
        "email": user["email"],
        "role": user["role"],
        "studio_name": user.get("studio_name"),
        "phone": user.get("phone"),
    }


# ─── Camera Routes ─────────────────────────────────────────────────────────────

def fmt_camera(c):
    return {
        "id": str(c["_id"]),
        "name": c["name"],
        "brand": c["brand"],
        "type": c["type"],
        "price_per_day": c["price_per_day"],
        "megapixels": c.get("megapixels"),
        "video": c.get("video"),
        "sensor": c.get("sensor"),
        "condition": c.get("condition", "Good"),
        "accessories": c.get("accessories"),
        "description": c.get("description"),
        "image_url": c.get("image_url"),
        "owner_id": str(c["owner_id"]),
        "owner_name": c.get("owner_name", ""),
        "status": c.get("status", "Available"),
        "rating": c.get("rating", 0.0),
        "review_count": c.get("review_count", 0),
        "created_at": c.get("created_at", datetime.utcnow()).isoformat(),
    }

@app.post("/cameras")
async def create_camera(camera: CameraIn, owner=Depends(require_owner)):
    doc = camera.dict()
    doc["owner_id"] = ObjectId(owner["_id"])
    doc["owner_name"] = owner.get("studio_name") or owner["name"]
    doc["status"] = "Available"
    doc["rating"] = 0.0
    doc["review_count"] = 0
    doc["created_at"] = datetime.utcnow()
    result = await db.cameras.insert_one(doc)
    created = await db.cameras.find_one({"_id": result.inserted_id})
    return fmt_camera(created)

@app.get("/cameras")
async def list_cameras(
    type: Optional[str] = None,
    max_price: Optional[float] = None,
    status: Optional[str] = None,
    search: Optional[str] = None,
    sort: Optional[str] = "price_asc"
):
    query = {}
    if type:
        query["type"] = type
    if max_price:
        query["price_per_day"] = {"$lte": max_price}
    if status:
        query["status"] = status
    if search:
        query["$or"] = [
            {"name": {"$regex": search, "$options": "i"}},
            {"brand": {"$regex": search, "$options": "i"}},
        ]
    
    sort_field = "price_per_day"
    sort_dir = 1
    if sort == "price_desc":
        sort_dir = -1
    elif sort == "rating":
        sort_field = "rating"
        sort_dir = -1

    cameras = await db.cameras.find(query).sort(sort_field, sort_dir).to_list(100)
    return [fmt_camera(c) for c in cameras]

@app.get("/cameras/owner")
async def my_cameras(owner=Depends(require_owner)):
    cameras = await db.cameras.find({"owner_id": ObjectId(owner["_id"])}).to_list(100)
    return [fmt_camera(c) for c in cameras]

@app.get("/cameras/{camera_id}")
async def get_camera(camera_id: str):
    c = await db.cameras.find_one({"_id": ObjectId(camera_id)})
    if not c:
        raise HTTPException(status_code=404, detail="Camera not found")
    return fmt_camera(c)

@app.put("/cameras/{camera_id}")
async def update_camera(camera_id: str, camera: CameraIn, owner=Depends(require_owner)):
    c = await db.cameras.find_one({"_id": ObjectId(camera_id)})
    if not c:
        raise HTTPException(status_code=404, detail="Camera not found")
    if str(c["owner_id"]) != str(owner["_id"]):
        raise HTTPException(status_code=403, detail="Not your camera")
    await db.cameras.update_one({"_id": ObjectId(camera_id)}, {"$set": camera.dict()})
    updated = await db.cameras.find_one({"_id": ObjectId(camera_id)})
    return fmt_camera(updated)

@app.delete("/cameras/{camera_id}")
async def delete_camera(camera_id: str, owner=Depends(require_owner)):
    c = await db.cameras.find_one({"_id": ObjectId(camera_id)})
    if not c:
        raise HTTPException(status_code=404, detail="Camera not found")
    if str(c["owner_id"]) != str(owner["_id"]):
        raise HTTPException(status_code=403, detail="Not your camera")
    await db.cameras.delete_one({"_id": ObjectId(camera_id)})
    return {"message": "Camera deleted"}


# ─── Booking Routes ────────────────────────────────────────────────────────────

def days_between(d1: str, d2: str) -> int:
    return max(1, (datetime.fromisoformat(d2) - datetime.fromisoformat(d1)).days)

def fmt_booking(b):
    return {
        "id": str(b["_id"]),
        "camera_id": str(b["camera_id"]),
        "camera_name": b.get("camera_name", ""),
        "camera_brand": b.get("camera_brand", ""),
        "owner_id": str(b["owner_id"]),
        "owner_name": b.get("owner_name", ""),
        "renter_id": str(b["renter_id"]),
        "renter_name": b.get("renter_name", ""),
        "renter_phone": b.get("renter_phone", ""),
        "renter_id_proof": b.get("renter_id_proof"),
        "issue_date": b["issue_date"],
        "return_date": b["return_date"],
        "offered_price": b["offered_price"],
        "listed_price": b["listed_price"],
        "bargain_reason": b.get("bargain_reason"),
        "notes": b.get("notes"),
        "status": b.get("status", "Pending"),
        "total_amount": b.get("total_amount", 0),
        "counter_price": b.get("counter_price"),
        "counter_message": b.get("counter_message"),
        "actual_return_date": b.get("actual_return_date"),
        "final_payment": b.get("final_payment"),
        "created_at": b.get("created_at", datetime.utcnow()).isoformat(),
    }

@app.post("/bookings")
async def create_booking(booking: BookingIn, renter=Depends(require_renter)):
    camera = await db.cameras.find_one({"_id": ObjectId(booking.camera_id)})
    if not camera:
        raise HTTPException(status_code=404, detail="Camera not found")
    if camera.get("status") == "Rented":
        raise HTTPException(status_code=400, detail="Camera already rented")
    
    days = days_between(booking.issue_date, booking.return_date)
    total = booking.offered_price * days

    doc = booking.dict()
    doc["camera_id"] = ObjectId(booking.camera_id)
    doc["owner_id"] = camera["owner_id"]
    doc["owner_name"] = camera.get("owner_name", "")
    doc["camera_name"] = camera["name"]
    doc["camera_brand"] = camera.get("brand", "")
    doc["renter_id"] = ObjectId(renter["_id"])
    doc["status"] = "Pending"
    doc["total_amount"] = total
    doc["created_at"] = datetime.utcnow()
    
    result = await db.bookings.insert_one(doc)
    created = await db.bookings.find_one({"_id": result.inserted_id})
    return fmt_booking(created)

@app.get("/bookings/owner")
async def owner_bookings(owner=Depends(require_owner)):
    bookings = await db.bookings.find({"owner_id": ObjectId(owner["_id"])}).sort("created_at", -1).to_list(200)
    return [fmt_booking(b) for b in bookings]

@app.get("/bookings/renter")
async def renter_bookings(renter=Depends(require_renter)):
    bookings = await db.bookings.find({"renter_id": ObjectId(renter["_id"])}).sort("created_at", -1).to_list(200)
    return [fmt_booking(b) for b in bookings]

@app.put("/bookings/{booking_id}/accept")
async def accept_booking(booking_id: str, owner=Depends(require_owner)):
    booking = await db.bookings.find_one({"_id": ObjectId(booking_id)})
    if not booking:
        raise HTTPException(status_code=404, detail="Booking not found")
    if str(booking["owner_id"]) != str(owner["_id"]):
        raise HTTPException(status_code=403, detail="Not your booking")
    
    await db.bookings.update_one({"_id": ObjectId(booking_id)}, {"$set": {"status": "Accepted"}})
    await db.cameras.update_one({"_id": booking["camera_id"]}, {"$set": {"status": "Rented"}})
    updated = await db.bookings.find_one({"_id": ObjectId(booking_id)})
    return fmt_booking(updated)

@app.put("/bookings/{booking_id}/reject")
async def reject_booking(booking_id: str, owner=Depends(require_owner)):
    booking = await db.bookings.find_one({"_id": ObjectId(booking_id)})
    if not booking:
        raise HTTPException(status_code=404, detail="Not found")
    if str(booking["owner_id"]) != str(owner["_id"]):
        raise HTTPException(status_code=403, detail="Not your booking")
    await db.bookings.update_one({"_id": ObjectId(booking_id)}, {"$set": {"status": "Rejected"}})
    updated = await db.bookings.find_one({"_id": ObjectId(booking_id)})
    return fmt_booking(updated)

@app.put("/bookings/{booking_id}/counter")
async def counter_offer(booking_id: str, data: BargainCounter, owner=Depends(require_owner)):
    booking = await db.bookings.find_one({"_id": ObjectId(booking_id)})
    if not booking:
        raise HTTPException(status_code=404, detail="Not found")
    if str(booking["owner_id"]) != str(owner["_id"]):
        raise HTTPException(status_code=403, detail="Not your booking")
    await db.bookings.update_one(
        {"_id": ObjectId(booking_id)},
        {"$set": {
            "status": "Counter",
            "counter_price": data.counter_price,
            "counter_message": data.message,
        }}
    )
    updated = await db.bookings.find_one({"_id": ObjectId(booking_id)})
    return fmt_booking(updated)

@app.put("/bookings/{booking_id}/return")
async def return_camera(
    booking_id: str,
    final_payment: float,
    return_condition: str = "Good",
    owner=Depends(require_owner)
):
    booking = await db.bookings.find_one({"_id": ObjectId(booking_id)})
    if not booking:
        raise HTTPException(status_code=404, detail="Not found")
    await db.bookings.update_one(
        {"_id": ObjectId(booking_id)},
        {"$set": {
            "status": "Returned",
            "actual_return_date": datetime.utcnow().isoformat(),
            "final_payment": final_payment,
            "return_condition": return_condition,
        }}
    )
    await db.cameras.update_one({"_id": booking["camera_id"]}, {"$set": {"status": "Available"}})
    updated = await db.bookings.find_one({"_id": ObjectId(booking_id)})
    return fmt_booking(updated)

@app.get("/dashboard/owner/stats")
async def owner_stats(owner=Depends(require_owner)):
    owner_id = ObjectId(owner["_id"])
    total_cameras = await db.cameras.count_documents({"owner_id": owner_id})
    available = await db.cameras.count_documents({"owner_id": owner_id, "status": "Available"})
    rented = await db.cameras.count_documents({"owner_id": owner_id, "status": "Rented"})
    pending = await db.bookings.count_documents({"owner_id": owner_id, "status": "Pending"})
    
    returned = await db.bookings.find({"owner_id": owner_id, "status": "Returned"}).to_list(1000)
    total_earnings = sum(b.get("final_payment") or b.get("total_amount", 0) for b in returned)
    
    active = await db.bookings.find({"owner_id": owner_id, "status": "Accepted"}).to_list(1000)
    
    return {
        "total_cameras": total_cameras,
        "available": available,
        "rented": rented,
        "pending_requests": pending,
        "total_earnings": total_earnings,
        "active_rentals": len(active),
    }

@app.get("/health")
async def health():
    return {"status": "ok"}
