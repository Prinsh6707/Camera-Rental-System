import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import toast from 'react-hot-toast';
import { IconCamera, IconUser, IconBuildingStore, IconMail, IconLock, IconEye, IconEyeOff } from '@tabler/icons-react';

export default function Login() {
  const { login } = useAuth();
  const navigate = useNavigate();
  const [role, setRole] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPw, setShowPw] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleLogin = async (e) => {
    e.preventDefault();
    if (!role) { toast.error('Please select a role'); return; }
    setLoading(true);
    try {
      const user = await login(email, password, role);
      toast.success(`Welcome back, ${user.name}!`);
      navigate(user.role === 'owner' ? '/owner' : '/browse');
    } catch (err) {
      toast.error(err.response?.data?.detail || 'Login failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="auth-page">
      <div className="auth-card">
        <div style={{ textAlign: 'center', marginBottom: '2rem' }}>
          <div style={{ width: 56, height: 56, background: 'var(--blue)', borderRadius: 16, display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 12px' }}>
            <IconCamera size={28} color="white" />
          </div>
          <h1 style={{ fontSize: 24, fontWeight: 700, color: 'var(--gray-900)' }}>CamRent</h1>
          <p style={{ fontSize: 13, color: 'var(--gray-500)', marginTop: 4 }}>Professional Camera Rental Platform</p>
        </div>

        <p style={{ fontSize: 12, fontWeight: 600, color: 'var(--gray-500)', textTransform: 'uppercase', letterSpacing: '.06em', marginBottom: 10 }}>Login as</p>
        <div className="grid-2" style={{ marginBottom: '1.25rem' }}>
          <button type="button" className={`auth-role-btn ${role === 'owner' ? 'selected' : ''}`} onClick={() => setRole('owner')}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
              <div style={{ width: 38, height: 38, borderRadius: 10, background: role === 'owner' ? 'var(--blue)' : 'var(--gray-100)', display: 'flex', alignItems: 'center', justifyContent: 'center', transition: 'all .15s' }}>
                <IconBuildingStore size={20} color={role === 'owner' ? 'white' : 'var(--gray-500)'} />
              </div>
              <div>
                <div style={{ fontWeight: 600, fontSize: 13, color: 'var(--gray-800)' }}>Camera Owner</div>
                <div style={{ fontSize: 11, color: 'var(--gray-500)' }}>Manage & rent out</div>
              </div>
            </div>
          </button>
          <button type="button" className={`auth-role-btn ${role === 'renter' ? 'selected' : ''}`} onClick={() => setRole('renter')}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
              <div style={{ width: 38, height: 38, borderRadius: 10, background: role === 'renter' ? 'var(--blue)' : 'var(--gray-100)', display: 'flex', alignItems: 'center', justifyContent: 'center', transition: 'all .15s' }}>
                <IconUser size={20} color={role === 'renter' ? 'white' : 'var(--gray-500)'} />
              </div>
              <div>
                <div style={{ fontWeight: 600, fontSize: 13, color: 'var(--gray-800)' }}>Renter</div>
                <div style={{ fontSize: 11, color: 'var(--gray-500)' }}>Browse & book</div>
              </div>
            </div>
          </button>
        </div>

        <div className="divider" />

        <form onSubmit={handleLogin} style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
          <div className="form-group">
            <label className="form-label">Email</label>
            <div className="input-group">
              <IconMail size={15} className="input-icon" />
              <input className="form-control" type="email" placeholder="you@example.com" value={email} onChange={e => setEmail(e.target.value)} required />
            </div>
          </div>
          <div className="form-group">
            <label className="form-label">Password</label>
            <div className="input-group" style={{ position: 'relative' }}>
              <IconLock size={15} className="input-icon" />
              <input className="form-control" type={showPw ? 'text' : 'password'} placeholder="••••••••" value={password} onChange={e => setPassword(e.target.value)} required style={{ paddingRight: 38 }} />
              <button type="button" onClick={() => setShowPw(!showPw)} style={{ position: 'absolute', right: 10, top: '50%', transform: 'translateY(-50%)', background: 'none', border: 'none', cursor: 'pointer', color: 'var(--gray-400)' }}>
                {showPw ? <IconEyeOff size={15} /> : <IconEye size={15} />}
              </button>
            </div>
          </div>
          <button type="submit" className="btn btn-primary btn-lg" style={{ width: '100%', justifyContent: 'center', marginTop: 4 }} disabled={loading}>
            {loading ? <><div className="spinner" style={{ width: 16, height: 16, borderWidth: 2, borderColor: 'rgba(255,255,255,.3)', borderTopColor: '#fff' }} /> Logging in...</> : 'Log In'}
          </button>
        </form>

        <p style={{ textAlign: 'center', marginTop: '1.25rem', fontSize: 13, color: 'var(--gray-500)' }}>
          Don't have an account? <Link to="/register" style={{ color: 'var(--blue)', fontWeight: 500 }}>Create one</Link>
        </p>
      </div>
    </div>
  );
}
