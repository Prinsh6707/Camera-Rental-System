import React from 'react';
import { IconTool, IconStar, IconEdit, IconTrash } from '@tabler/icons-react';

const CAMERA_EMOJI = { DSLR: '📷', Mirrorless: '🎞️', Cinema: '🎬', Action: '🏄' };

export function StatusBadge({ status }) {
  const cls = {
    Available: 'badge-available',
    Rented: 'badge-rented',
    Pending: 'badge-pending',
    Accepted: 'badge-accepted',
    Rejected: 'badge-rejected',
    Returned: 'badge-returned',
    Counter: 'badge-counter',
  }[status] || 'badge-pending';
  return <span className={`badge ${cls}`}>{status}</span>;
}

export function CameraCardOwner({ camera, onEdit, onDelete }) {
  return (
    <div className="camera-card">
      <div className="camera-card-img">
        {camera.image_url
          ? <img src={camera.image_url} alt={camera.name} />
          : <span>{CAMERA_EMOJI[camera.type] || '📷'}</span>}
        <div style={{ position: 'absolute', top: 10, right: 10 }}>
          <StatusBadge status={camera.status} />
        </div>
      </div>
      <div className="camera-card-body">
        <div className="flex-between mb-1">
          <div>
            <div className="camera-name">{camera.name}</div>
            <div className="camera-brand">{camera.brand} · {camera.type}</div>
          </div>
        </div>
        <div className="camera-specs">
          <div className="camera-spec"><strong>{camera.megapixels || '—'}</strong> MP</div>
          <div className="camera-spec"><strong>{camera.video || '—'}</strong></div>
          <div className="camera-spec">{camera.sensor || '—'}</div>
          <div className="camera-spec">{camera.condition}</div>
        </div>
        {camera.accessories && (
          <div style={{ fontSize: 11, color: 'var(--gray-400)', marginBottom: 10, display: 'flex', alignItems: 'center', gap: 4 }}>
            <IconTool size={11} /> <span style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{camera.accessories}</span>
          </div>
        )}
        <div className="flex-between" style={{ marginTop: 8 }}>
          <div>
            <span className="camera-price">₹{camera.price_per_day.toLocaleString('en-IN')}</span>
            <span style={{ fontSize: 11, color: 'var(--gray-400)' }}>/day</span>
          </div>
          <div style={{ display: 'flex', gap: 6 }}>
            <button className="btn-icon" onClick={() => onEdit(camera)} title="Edit"><IconEdit size={14} /></button>
            <button className="btn-icon" onClick={() => onDelete(camera.id)} title="Delete" style={{ background: 'var(--red-light)', color: 'var(--red)' }}><IconTrash size={14} /></button>
          </div>
        </div>
      </div>
    </div>
  );
}

export function CameraCardRenter({ camera, onBook }) {
  const stars = Math.round(camera.rating || 0);
  return (
    <div className="camera-card">
      <div className="camera-card-img">
        {camera.image_url
          ? <img src={camera.image_url} alt={camera.name} />
          : <span>{CAMERA_EMOJI[camera.type] || '📷'}</span>}
        <div style={{ position: 'absolute', top: 10, right: 10 }}>
          <StatusBadge status={camera.status} />
        </div>
      </div>
      <div className="camera-card-body">
        <div className="camera-name">{camera.name}</div>
        <div className="camera-brand">{camera.brand} · {camera.type}</div>
        <div className="stars" style={{ margin: '6px 0 8px', display: 'flex', alignItems: 'center', gap: 4 }}>
          {'★'.repeat(stars)}{'☆'.repeat(5 - stars)}
          <span style={{ fontSize: 11, color: 'var(--gray-500)' }}>{camera.rating ? camera.rating.toFixed(1) : 'New'} ({camera.review_count} reviews)</span>
        </div>
        <div className="camera-specs">
          <div className="camera-spec"><strong>{camera.sensor || '—'}</strong></div>
          <div className="camera-spec"><strong>{camera.video || '—'}</strong></div>
          <div className="camera-spec">{camera.megapixels || '—'} MP</div>
          <div className="camera-spec" style={{ color: camera.condition === 'Excellent' ? 'var(--green)' : 'var(--amber)' }}>{camera.condition}</div>
        </div>
        {camera.accessories && (
          <div style={{ fontSize: 11, color: 'var(--gray-400)', margin: '6px 0 8px', display: 'flex', alignItems: 'center', gap: 4 }}>
            <IconTool size={11} /> <span style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{camera.accessories}</span>
          </div>
        )}
        {camera.description && (
          <p style={{ fontSize: 11, color: 'var(--gray-500)', margin: '0 0 10px', lineHeight: 1.5, display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical', overflow: 'hidden' }}>{camera.description}</p>
        )}
        <div className="flex-between" style={{ marginTop: 8, borderTop: '1px solid var(--gray-100)', paddingTop: 10 }}>
          <div>
            <span style={{ fontSize: 11, color: 'var(--gray-500)' }}>by {camera.owner_name}</span>
            <div>
              <span className="camera-price">₹{camera.price_per_day.toLocaleString('en-IN')}</span>
              <span style={{ fontSize: 11, color: 'var(--gray-400)' }}>/day</span>
            </div>
          </div>
          <button
            className={`btn ${camera.status === 'Available' ? 'btn-primary' : 'btn-secondary'} btn-sm`}
            onClick={() => camera.status === 'Available' && onBook(camera)}
            disabled={camera.status !== 'Available'}
          >
            {camera.status === 'Available' ? 'Book Now' : 'Unavailable'}
          </button>
        </div>
      </div>
    </div>
  );
}
