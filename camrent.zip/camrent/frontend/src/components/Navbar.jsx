import React from 'react';
import { useAuth } from '../context/AuthContext';
import { useNavigate } from 'react-router-dom';
import { IconCamera, IconLogout, IconUser } from '@tabler/icons-react';

export default function Navbar({ children }) {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <div style={{ minHeight: '100vh', background: 'var(--gray-50)' }}>
      <nav className="navbar">
        <a className="navbar-brand" href="#">
          <div className="navbar-brand-icon"><IconCamera size={18} /></div>
          <span className="navbar-brand-name">CamRent</span>
          {user?.role === 'owner' && (
            <span style={{ fontSize: 10, background: 'var(--blue-light)', color: 'var(--blue)', borderRadius: 6, padding: '2px 7px', fontWeight: 600, marginLeft: 6 }}>OWNER</span>
          )}
        </a>
        <div className="navbar-actions">
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '5px 10px', background: 'var(--gray-50)', borderRadius: 'var(--radius-sm)' }}>
            <div className="avatar" style={{ width: 28, height: 28, fontSize: 11 }}>{(user?.name || 'U').charAt(0).toUpperCase()}</div>
            <div>
              <div style={{ fontSize: 12, fontWeight: 600, color: 'var(--gray-800)', lineHeight: 1.2 }}>{user?.name}</div>
              {user?.studio_name && <div style={{ fontSize: 10, color: 'var(--gray-500)' }}>{user.studio_name}</div>}
            </div>
          </div>
          <button className="btn-icon" onClick={handleLogout} title="Logout"><IconLogout size={16} /></button>
        </div>
      </nav>
      {children}
    </div>
  );
}
